﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HappyTech
{
    class Section
    {

        private void createSection(int sectionNumber)
        {
            Panel section = new Panel();

           // sectionNumber.Location = new Point(10,130);
        }

    }
}
